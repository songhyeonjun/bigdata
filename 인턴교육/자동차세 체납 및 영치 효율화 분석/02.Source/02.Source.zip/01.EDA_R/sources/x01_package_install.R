# 패키지 설치
install.packages("sqldf")
install.packages("stringr")
install.packages("plyr")
install.packages("dplyr")
install.packages("ggplot2")