# 환경 초기화
rm(list = ls())

# 패키지 부착
library(sqldf)
library(stringr)
library(plyr)
library(dplyr)
library(ggplot2)

## 파일 읽어오기
youngchi <- data.frame(read.csv("./data/01_youngchi.csv", na.strings = '')) #영치
chenap <- data.frame(read.csv("./data/02_chenap.csv", na.strings = '')) #체납
carreg <- data.frame(read.csv("./data/03_carreg.csv", na.strings = '')) #차량등록

print("01_load: 패키지 부착 및 데이터 로드 완료")
